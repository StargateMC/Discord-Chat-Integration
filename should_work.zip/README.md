# Discord-Chat-Integration
This mod links your server chat with a channel on your discord server.

Quick setup guide: https://github.com/ErdbeerbaerLP/Discord-Chat-Integration/wiki
